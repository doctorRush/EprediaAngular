export interface IDeviceMetadata {
    
    deviceId: any,
    request: string,
    chamber_status: string,
    date: string,
    protocol_name: string,
    reagent_name:string
      }
      