export interface IEventParameters {
    
    event_type: any,
    description: string,
    commercial_region: string,
    service_region: string,
    error_code: string,
    
      }