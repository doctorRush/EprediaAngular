export interface HubData {
    data: any;
}