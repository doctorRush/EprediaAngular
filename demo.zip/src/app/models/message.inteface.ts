export class Message {

    constructor(
        public clientuniqueid?: any,
        public type?: any,
        public message?: any,
        public date?: any
    ){}
    
}  