export interface IDevice {

_id: number;
deviceName: string;
serialNumber: string;
firmwareVersion: string;
softwareVersion: string;
status: string;
  }
