import { IDevice } from '../device.interface';

export interface IDeviceHttp {
  devices: IDevice[];
}
