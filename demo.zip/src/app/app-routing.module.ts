import { MainComponent } from './components/main.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DeviceComponent } from './containers/device/device/device.component';
import { LoginComponent } from './components/login/login.component';
import { AuthGuard } from 'src/core/guards/auth.guard';
import { ChartDemoComponent } from './components/chart-demo/chart-demo.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: 'devices', component: MainComponent,canActivate: [
      AuthGuard
    ]
  },
  // {
  //   path: 'devices', component: MainComponent
  // },
  {
    path: 'chart-demo', component: ChartDemoComponent
  },
  { path: 'device/:id', component: DeviceComponent,canActivate: [
    AuthGuard
  ] },
  { path: '', redirectTo:"/login" ,pathMatch:"full"}

];

@NgModule({
 // imports: [RouterModule.forRoot(routes, { useHash: true })],
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
