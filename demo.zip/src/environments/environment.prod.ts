export const environment = {
  production: true,
  username: 'naman',
  hubUrl: 'https://epredia-azure-functions-20200326120440728.azurewebsites.net/api',
  dataListenerKey: 'Hub'

};
